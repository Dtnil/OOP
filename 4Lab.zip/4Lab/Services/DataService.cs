using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using SportApp.Models;

namespace SportApp.Services
{
    
    public class CompetitorDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
    }

    public class PerformanceDto
    {
        public CompetitorDto Competitor { get; set; }
        public bool IsTeamCompetition { get; set; }
        public double Result { get; set; }
        public int OrderNumber { get; set; }
    }

    public class CompetitionDto
    {
        public string Name { get; set; }
        public List<PerformanceDto> Performances { get; set; } = new();
    }

    public class AppDataDto
    {
        public List<CompetitionDto> Competitions { get; set; } = new();
        public DateTime SavedAt { get; set; }
        public string SavedBy { get; set; }
    }

    public static class DataService
    {
        private static readonly JsonSerializerOptions _options = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNameCaseInsensitive = true
        };

        public static void SaveToFile(List<Competition> competitions, string filePath, string authorName = "")
        {
            var dto = new AppDataDto
            {
                SavedAt = DateTime.Now,
                SavedBy = string.IsNullOrWhiteSpace(authorName) ? Environment.UserName : authorName,
                Competitions = new List<CompetitionDto>()
            };

            foreach (var comp in competitions)
            {
                var compDto = new CompetitionDto { Name = comp.Name };
                foreach (var perf in comp.Performances)
                {
                    compDto.Performances.Add(new PerformanceDto
                    {
                        IsTeamCompetition = perf.IsTeamCompetition,
                        Result = perf.Result,
                        OrderNumber = perf.OrderNumber,
                        Competitor = new CompetitorDto
                        {
                            FirstName = perf.Competitor.FirstName,
                            LastName = perf.Competitor.LastName,
                            BirthDate = perf.Competitor.BirthDate
                        }
                    });
                }
                dto.Competitions.Add(compDto);
            }

            string json = JsonSerializer.Serialize(dto, _options);
            File.WriteAllText(filePath, json);
        }

        public static (List<Competition> competitions, AppDataDto meta) LoadFromFile(string filePath)
        {
            if (!File.Exists(filePath))
                return (new List<Competition>(), null);

            string json = File.ReadAllText(filePath);
            var dto = JsonSerializer.Deserialize<AppDataDto>(json, _options);

            Performance.ResetCounter();
            var competitions = new List<Competition>();

            foreach (var compDto in dto.Competitions)
            {
                var comp = new Competition(compDto.Name);
                foreach (var perfDto in compDto.Performances)
                {
                    var competitor = new Competitor(
                        perfDto.Competitor.FirstName,
                        perfDto.Competitor.LastName,
                        perfDto.Competitor.BirthDate);

                    var perf = new Performance(competitor, perfDto.IsTeamCompetition, perfDto.Result);
                    comp.AddPerformance(perf);
                }
                competitions.Add(comp);
            }

            return (competitions, dto);
        }

        public static void ExportToText(List<Competition> competitions, string filePath)
        {
            using var writer = new StreamWriter(filePath, false, System.Text.Encoding.UTF8);
            writer.WriteLine($"ЗВІТ ЗМАГАНЬ");
            writer.WriteLine($"Створено: {DateTime.Now:dd.MM.yyyy HH:mm:ss}");
            writer.WriteLine(new string('=', 60));
            writer.WriteLine();

            foreach (var comp in competitions)
            {
                writer.WriteLine(comp.ToString());
                writer.WriteLine(new string('-', 60));
            }
        }
    }
}
