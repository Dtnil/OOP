using System;
using System.Globalization;
using System.Windows.Data;

namespace SportApp.Converters
{
    public class BoolToTeamConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isTeam)
                return isTeam ? "🤝 Командні" : "👤 Індивідуальні";
            return "—";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
