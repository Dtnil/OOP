using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using SportApp.Models;
using SportApp.Services;

namespace SportApp
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<Competition> _competitions = new();
        private string _currentFilePath = "";
        private string _sharedFolderPath = "";

        public MainWindow()
        {
            InitializeComponent();
            CompetitionsList.ItemsSource = _competitions;
            CompetitionSelector.ItemsSource = _competitions;
            BirthDatePicker.SelectedDate = new DateTime(1995, 1, 1);
            UpdateStats();
        }

        // Додати змагання
        private void AddCompetition_Click(object sender, RoutedEventArgs e)
        {
            string name = CompetitionNameBox.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                SetStatus("⚠️ Введіть назву змагання!", isError: true);
                return;
            }

            var comp = new Competition(name);
            _competitions.Add(comp);
            CompetitionNameBox.Clear();
            CompetitionsList.SelectedItem = comp;
            CompetitionSelector.SelectedItem = comp;
            UpdateStats();
            SetStatus($"✅ Змагання «{name}» створено!");
        }

        // Додати виступ
        private void AddPerformance_Click(object sender, RoutedEventArgs e)
        {
            if (CompetitionSelector.SelectedItem is not Competition selectedComp)
            {
                SetStatus("⚠️ Оберіть змагання!", isError: true);
                return;
            }

            string firstName = FirstNameBox.Text.Trim();
            string lastName = LastNameBox.Text.Trim();

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
            {
                SetStatus("⚠️ Введіть ім'я та прізвище!", isError: true);
                return;
            }

            if (!double.TryParse(ResultBox.Text.Replace(',', '.'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out double result))
            {
                SetStatus("⚠️ Невірний формат результату!", isError: true);
                return;
            }

            DateTime birthDate = BirthDatePicker.SelectedDate ?? DateTime.Today;
            bool isTeam = IsTeamCheckBox.IsChecked == true;

            var competitor = new Competitor(firstName, lastName, birthDate);
            var performance = new Performance(competitor, isTeam, result);
            selectedComp.AddPerformance(performance);

            // Оновлення
            RefreshPerformances(selectedComp);
            RefreshCompetitionList();
            UpdateStats();
            ClearPerformanceFields();
            SetStatus($"✅ Виступ {lastName} {firstName} додано до «{selectedComp.Name}»!");

            // авто збереження
            AutoSaveToSharedFolder();
        }

        // видалити
        private void DeleteCompetition_Click(object sender, RoutedEventArgs e)
        {
            if (CompetitionsList.SelectedItem is not Competition selected) return;

            var result = MessageBox.Show(
                $"Видалити змагання «{selected.Name}» та всі виступи?",
                "Підтвердження", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                _competitions.Remove(selected);
                PerformancesList.ItemsSource = null;
                WinnerBadge.Visibility = Visibility.Collapsed;
                UpdateStats();
                SetStatus($"🗑️ Змагання «{selected.Name}» видалено.");
            }
        }

        // Очищеня
        private void ClearForm_Click(object sender, RoutedEventArgs e)
        {
            ClearPerformanceFields();
            SetStatus("🔄 Форму очищено.");
        }

        private void ClearPerformanceFields()
        {
            FirstNameBox.Clear();
            LastNameBox.Clear();
            ResultBox.Clear();
            BirthDatePicker.SelectedDate = new DateTime(1995, 1, 1);
            IsTeamCheckBox.IsChecked = false;
        }

        // Вибір змагань
        private void CompetitionsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CompetitionsList.SelectedItem is Competition comp)
            {
                CompetitionSelector.SelectedItem = comp;
                RefreshPerformances(comp);
            }
        }

        private void RefreshPerformances(Competition comp)
        {
            PerformancesList.ItemsSource = null;
            PerformancesList.ItemsSource = comp.Performances;

            var winner = comp.GetWinner();
            if (winner != null)
            {
                WinnerBadge.Visibility = Visibility.Visible;
                WinnerText.Text = $"🏆 Переможець: {winner.Competitor.LastName} ({winner.Result:F2})";
            }
            else
            {
                WinnerBadge.Visibility = Visibility.Collapsed;
            }
        }

        private void RefreshCompetitionList()
        {
            var sel = CompetitionsList.SelectedItem;
            CompetitionsList.ItemsSource = null;
            CompetitionsList.ItemsSource = _competitions;
            CompetitionsList.SelectedItem = sel;
        }

        // Збереження
        private void SaveData_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new SaveFileDialog
            {
                Filter = "JSON файли (*.json)|*.json|Всі файли (*.*)|*.*",
                DefaultExt = "json",
                FileName = "zmahanya",
                Title = "Зберегти дані змагань"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    DataService.SaveToFile(_competitions.ToList(), dialog.FileName);
                    _currentFilePath = dialog.FileName;
                    FilePath.Text = Path.GetFileName(_currentFilePath);
                    SetStatus($"✅ Збережено: {Path.GetFileName(_currentFilePath)}");
                }
                catch (Exception ex)
                {
                    SetStatus($"❌ Помилка збереження: {ex.Message}", isError: true);
                }
            }
        }

        // загрузка
        private void LoadData_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "JSON файли (*.json)|*.json|Всі файли (*.*)|*.*",
                Title = "Відкрити дані змагань"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var (comps, meta) = DataService.LoadFromFile(dialog.FileName);
                    _competitions.Clear();
                    foreach (var c in comps)
                        _competitions.Add(c);

                    _currentFilePath = dialog.FileName;
                    FilePath.Text = Path.GetFileName(_currentFilePath);
                    UpdateStats();

                    string metaInfo = meta != null
                        ? $" (збережено: {meta.SavedBy}, {meta.SavedAt:dd.MM.yyyy HH:mm})"
                        : "";

                    SetStatus($"✅ Завантажено {comps.Count} змагань{metaInfo}");

                    if (meta != null && meta.SavedBy != Environment.UserName)
                    {
                        MessageBox.Show(
                            $"📡 Дані завантажено від користувача: {meta.SavedBy}\n" +
                            $"Дата збереження: {meta.SavedAt:dd.MM.yyyy HH:mm:ss}\n\n" +
                            $"Змагань: {comps.Count}\n" +
                            $"Виступів: {comps.Sum(c => c.Performances.Count)}",
                            "Дані від іншого користувача",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    SetStatus($"❌ Помилка завантаження: {ex.Message}", isError: true);
                }
            }
        }

        // Експорт в тхт
        private void ExportTxt_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new SaveFileDialog
            {
                Filter = "Текстові файли (*.txt)|*.txt",
                DefaultExt = "txt",
                FileName = "zvit_zmahan",
                Title = "Експорт звіту"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    DataService.ExportToText(_competitions.ToList(), dialog.FileName);
                    SetStatus($"📤 Звіт експортовано: {Path.GetFileName(dialog.FileName)}");

                    if (MessageBox.Show("Відкрити файл?", "Експорт",
                        MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                        System.Diagnostics.Process.Start("notepad.exe", dialog.FileName);
                }
                catch (Exception ex)
                {
                    SetStatus($"❌ Помилка експорту: {ex.Message}", isError: true);
                }
            }
        }

        //SET SHARED FOLDER 
        private void SetSharedFolder_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFolderDialog
            {
                Title = "Оберіть спільну папку (Google Drive / OneDrive)"
            };

            if (dialog.ShowDialog() == true)
            {
                _sharedFolderPath = dialog.FolderName;
                SetStatus($"📁 Спільна папка: {_sharedFolderPath}");
                MessageBox.Show(
                    $"✅ Спільна папка налаштована:\n{_sharedFolderPath}\n\n" +
                    "Дані автоматично зберігатимуться туди після кожного виступу.\n\n" +
                    "📌 Щоб інші бачили ваші дані — надайте їм доступ до цієї папки " +
                    "(наприклад, через Google Drive або OneDrive).\n\n" +
                    "📌 Щоб ви бачили їхні дані — вони мають зберегти файл у цю ж папку, " +
                    "а ви відкрити його через кнопку «Відкрити».",
                    "Спільний доступ", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Авто збереження в спільній папці
        private void AutoSaveToSharedFolder()
        {
            if (string.IsNullOrEmpty(_sharedFolderPath)) return;
            try
            {
                string path = Path.Combine(_sharedFolderPath, "shared_zmahanya.json");
                DataService.SaveToFile(_competitions.ToList(), path, Environment.UserName);
            }
            catch { /* silently ignore auto-save errors */ }
        }

        // Характеристики
        private void UpdateStats()
        {
            int total = _competitions.Sum(c => c.Performances.Count);
            TotalPerfCount.Text = total.ToString();
            TotalStatsText.Text = $"Змагань: {_competitions.Count}  |  Виступів: {total}";
        }

        private void SetStatus(string message, bool isError = false)
        {
            StatusText.Text = message;
            StatusText.Foreground = isError
                ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 82, 82))
                : new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(139, 174, 200));
        }
    }
}
