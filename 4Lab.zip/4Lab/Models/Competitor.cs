using System;

namespace SportApp.Models
{
    public class Competitor
    {
        private string _firstName;
        private string _lastName;
        private DateTime _birthDate;

        public string FirstName
        {
            get => _firstName;
            set => _firstName = value ?? throw new ArgumentNullException(nameof(value));
        }

        public string LastName
        {
            get => _lastName;
            set => _lastName = value ?? throw new ArgumentNullException(nameof(value));
        }

        public DateTime BirthDate
        {
            get => _birthDate;
            set => _birthDate = value;
        }

        public Competitor() { }

        public Competitor(string firstName, string lastName, DateTime birthDate)
        {
            _firstName = firstName;
            _lastName = lastName;
            _birthDate = birthDate;
        }

        public override string ToString()
            => $"{_firstName} {_lastName} (нар. {_birthDate:dd.MM.yyyy})";
    }
}
