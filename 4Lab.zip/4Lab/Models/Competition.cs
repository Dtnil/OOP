using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SportApp.Models
{
    public class Competition
    {
        private string _name;
        private List<Performance> _performances;

        public string Name
        {
            get => _name;
            set => _name = value ?? throw new ArgumentNullException(nameof(value));
        }

        public List<Performance> Performances => _performances;

        public Competition()
        {
            _performances = new List<Performance>();
        }

        public Competition(string name)
        {
            _name = name;
            _performances = new List<Performance>();
        }

        public void AddPerformance(Performance performance)
        {
            if (performance == null) throw new ArgumentNullException(nameof(performance));
            _performances.Add(performance);
        }

        public Performance GetWinner()
        {
            if (_performances == null || _performances.Count == 0) return null;
            return _performances.OrderByDescending(p => p.Result).First();
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"=== Змагання: {_name} ===");
            sb.AppendLine($"Всього виступів: {_performances.Count}");
            sb.AppendLine();
            foreach (var p in _performances)
                sb.AppendLine(p.ToString());

            var winner = GetWinner();
            if (winner != null)
                sb.AppendLine($"\n🏆 Переможець: {winner.Competitor.LastName} {winner.Competitor.FirstName} (Результат: {winner.Result:F2})");

            return sb.ToString();
        }

        public string ToShortString()
        {
            var winner = GetWinner();
            string winnerLastName = winner != null ? winner.Competitor.LastName : "—";
            return $"Змагання: {_name} | Переможець: {winnerLastName}";
        }
    }
}
