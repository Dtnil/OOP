namespace SportApp.Models
{
    public class Performance
    {
        private bool _isTeamCompetition;
        private static int _totalPerformances = 0;
        private Competitor _competitor;
        private int _orderNumber;
        private double _result;

        public static int TotalPerformances => _totalPerformances;

        public bool IsTeamCompetition
        {
            get => _isTeamCompetition;
            set => _isTeamCompetition = value;
        }

        public Competitor Competitor
        {
            get => _competitor;
            set => _competitor = value;
        }

        public int OrderNumber => _orderNumber;

        public double Result
        {
            get => _result;
            set => _result = value;
        }

        public Performance()
        {
            _totalPerformances++;
            _orderNumber = _totalPerformances;
        }

        public Performance(Competitor competitor, bool isTeamCompetition, double result)
        {
            _competitor = competitor;
            _isTeamCompetition = isTeamCompetition;
            _result = result;
            _totalPerformances++;
            _orderNumber = _totalPerformances;
        }

        public static void ResetCounter() => _totalPerformances = 0;

        public override string ToString()
            => $"#{_orderNumber} | {_competitor} | {(_isTeamCompetition ? "Командні" : "Індивідуальні")} | Результат: {_result:F2}";
    }
}
