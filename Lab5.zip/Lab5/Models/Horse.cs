using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Media;

namespace HorseRaceApp.Models
{
    public class Horse : INotifyPropertyChanged
    {
        // ── Public read-only identity ─────────────────────────────────────────
        public string Name      { get; private set; }
        public Color  Color     { get; private set; }
        public double Speed     { get; private set; }
        public int    LaneIndex { get; set; }

        // ── Mutable race state ────────────────────────────────────────────────
        private double   _positionX;
        private TimeSpan _raceTime;
        private int      _position;
        private double   _coefficient;
        private double   _winnings;
        private int      _frameIndex;
        private double   _acceleration;

        public double   PositionX    { get => _positionX;    set { _positionX    = value; OnPropertyChanged(); } }
        public TimeSpan RaceTime     { get => _raceTime;     set { _raceTime     = value; OnPropertyChanged(); } }
        public int      Position     { get => _position;     set { _position     = value; OnPropertyChanged(); } }
        public double   Coefficient  { get => _coefficient;  set { _coefficient  = value; OnPropertyChanged(); } }
        public double   Winnings     { get => _winnings;     set { _winnings     = value; OnPropertyChanged(); } }
        public int      FrameIndex   { get => _frameIndex;   set { _frameIndex   = value; OnPropertyChanged(); } }
        public double   Acceleration { get => _acceleration; private set => _acceleration = value; }

        public bool Finished { get; set; }

        // ── DataGrid helpers ──────────────────────────────────────────────────
        public SolidColorBrush ColorBrush => new(Color);

        private static readonly Random _rng = new();
        private const int FrameCount = 12;

        public Horse(string name, Color color, int laneIndex)
        {
            Name        = name;
            Color       = color;
            LaneIndex   = laneIndex;
            Speed       = _rng.Next(5, 11);       // 5–10 px/tick
            Coefficient = Math.Round(1.25 + _rng.NextDouble() * 2.5, 2);
        }

        public void Reset()
        {
            PositionX    = 0;
            RaceTime     = TimeSpan.Zero;
            Finished     = false;
            FrameIndex   = 0;
            Acceleration = 0;
            Speed        = _rng.Next(5, 11);       // re-randomize each race
            Coefficient  = Math.Round(1.25 + _rng.NextDouble() * 2.5, 2);
            Position     = _rng.Next(1, 100);
            Winnings     = 0;
        }

        /// <summary>
        /// Async task per horse: randomly changes acceleration every ~16 ms.
        /// Runs until horse finishes or token is cancelled.
        /// Pattern: Task.WhenAll(list of these tasks) from RaceService.
        /// </summary>
        public async Task ChangeAcceleration(double traceEnd, Stopwatch timer,
                                             System.Threading.CancellationToken ct)
        {
            while (!Finished && !ct.IsCancellationRequested)
            {
                double factor = 0.7 + _rng.NextDouble() * 0.3;   // 0.7–1.0
                Acceleration = Speed * factor;
                RaceTime = timer.Elapsed;
                await Task.Delay(16, ct).ContinueWith(_ => { });  // swallow cancellation
            }
        }

        /// <summary>Called by render loop; advances animation frame index.</summary>
        public void AdvanceFrame()
        {
            FrameIndex = (FrameIndex + 1) % FrameCount;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }
}
