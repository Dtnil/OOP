using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using HorseRaceApp.Models;
using HorseRaceApp.Services;

namespace HorseRaceApp
{
    public partial class MainWindow : Window
    {
        // ── Services ──────────────────────────────────────────────────────────
        private readonly RaceService    _race    = new();
        private readonly BettingService _betting = new();
        private readonly VoronoiService _voronoi = new();
        private RenderService?          _renderer;

        // ── Race UI state ─────────────────────────────────────────────────────
        private int _cameraIdx   = -1;   // -1 = free camera
        private int _betHorseIdx = 0;

        // ── Voronoi state ─────────────────────────────────────────────────────
        private Color _vorColor = Colors.OrangeRed;

        private static readonly Color[] VorPalette =
        {
            Colors.OrangeRed, Colors.DodgerBlue, Colors.LimeGreen, Colors.Gold,
            Colors.MediumOrchid, Colors.Cyan, Colors.HotPink, Colors.Coral,
            Colors.SpringGreen, Colors.Tomato, Colors.Aquamarine, Colors.Salmon,
        };

        // ─────────────────────────────────────────────────────────────────────
        public MainWindow()
        {
            InitializeComponent();
            _betting.PropertyChanged += (_, _) => RefreshBettingUI();

            // Subscribe race events
            _race.RenderTick   += OnRenderTick;
            _race.RaceFinished += OnRaceFinished;

            InitRaceHorses(4);
            InitVorColorPicker();

            Loaded += (_, _) => Dispatcher.InvokeAsync(BuildRenderer);
        }

        // ══════════════════════════════════════════════════════════════════════
        //  RACE TAB
        // ══════════════════════════════════════════════════════════════════════

        private void BuildRenderer()
        {
            int w = Math.Max(100, (int)TrackImage.ActualWidth);
            int h = Math.Max(60,  (int)TrackImage.ActualHeight);
            _renderer = new RenderService(w, h, _race.Horses.Count, _race.TraceLength);
            DrawStaticFrame();
        }

        private void InitRaceHorses(int count)
        {
            _race.SetHorseCount(count);
            _betHorseIdx = 0;

            // Guard: XAML may not have finished loading yet (LstCount fires
            // SelectionChanged during InitializeComponent before RaceGrid exists)
            if (RaceGrid == null) return;

            RaceGrid.ItemsSource = _race.Horses;
            RefreshBettingUI();
            UpdatePickedHorse();
        }

        private void DrawStaticFrame()
        {
            if (_renderer == null) return;
            var bmp = _renderer.RenderFrame(_race.Horses.ToList());
            TrackImage.Source = bmp;
        }

        // ── Render tick (called from RaceService on UI thread) ────────────────
        private void OnRenderTick()
        {
            if (_renderer == null) return;

            // Camera follow logic
            if (_cameraIdx >= 0 && _cameraIdx < _race.Horses.Count)
            {
                var followed = _race.Horses[_cameraIdx];
                double scaleX = _renderer.TraceLength > 0
                    ? (int)TrackImage.ActualWidth / _renderer.TraceLength
                    : 1;
                double cx = followed.PositionX * scaleX - TrackImage.ActualWidth / 2;
                _renderer.CameraOffsetX = Math.Max(0,
                    Math.Min(cx, _renderer.TraceLength * scaleX - TrackImage.ActualWidth));
            }
            else
            {
                _renderer.CameraOffsetX = 0;
            }

            TrackImage.Source = _renderer.RenderFrame(_race.Horses.ToList());

            // Refresh DataGrid using LINQ sort by Position
            var sorted = _race.Horses.OrderBy(h => h.Position).ToList();
            RaceGrid.ItemsSource = null;
            RaceGrid.ItemsSource = sorted;
        }

        private void OnRaceFinished()
        {
            try
            {
                var winner = _race.Winner;
                double won = winner != null ? _betting.SettleBet(winner) : 0;
                RefreshBettingUI();
                BtnStart.IsEnabled = true;
                BtnStop.IsEnabled  = false;

                string winnerName = winner?.Name ?? "невідомо";
                string raceTime   = winner != null
                    ? winner.RaceTime.ToString(@"mm\:ss\.ff")
                    : "—";

                string msg = $"Переможець: {winnerName}\nЧас: {raceTime}";
                if (won > 0)
                    msg += $"\n\nВи виграли: {won:F2} $";

                MessageBox.Show(msg, "Гонка завершена!",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при завершенні гонки: {ex.Message}",
                    "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshBettingUI()
        {
            TxtBalance.Text       = $"{_betting.Balance:F2} $";
            TxtBalance.Foreground = _betting.Balance >= 50 ? Brushes.LimeGreen : Brushes.OrangeRed;
        }

        private void UpdatePickedHorse()
        {
            if (_race.Horses.Count == 0) { TxtPickedHorse.Text = "—"; return; }
            _betHorseIdx = Math.Clamp(_betHorseIdx, 0, _race.Horses.Count - 1);
            var h = _race.Horses[_betHorseIdx];
            TxtPickedHorse.Text = $"{h.Name}  (x{h.Coefficient:F2})";
        }

        // ── Buttons ───────────────────────────────────────────────────────────

        private async void Start_Click(object sender, RoutedEventArgs e)
        {
            BtnStart.IsEnabled = false;
            BtnStop.IsEnabled  = true;
            TxtInfo.Text       = "Гонка розпочалась!";
            TxtBetStatus.Text  = "";

            // Rebuild renderer in case the window was resized
            BuildRenderer();

            await _race.StartRace();
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            _race.StopRace();
            BtnStart.IsEnabled = true;
            BtnStop.IsEnabled  = false;
            TxtInfo.Text       = "Зупинено";
        }
        
        private void LstCount_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (_race.IsRunning) return;
            var item = LstCount.SelectedItem as ListBoxItem;
            if (item == null || !int.TryParse(item.Content?.ToString(), out int cnt)) return;
            InitRaceHorses(cnt);
            Dispatcher.InvokeAsync(BuildRenderer);
        }

        // Betting
        private void BetDec_Click(object s, RoutedEventArgs e)
        {
            if (double.TryParse(TxtBet.Text, out double v)) TxtBet.Text = Math.Max(5, v - 5).ToString("F0");
        }
        private void BetInc_Click(object s, RoutedEventArgs e)
        {
            if (double.TryParse(TxtBet.Text, out double v)) TxtBet.Text = (v + 5).ToString("F0");
        }
        private void HorsePrev_Click(object s, RoutedEventArgs e)
        {
            if (_race.Horses.Count == 0) return;
            _betHorseIdx = (_betHorseIdx - 1 + _race.Horses.Count) % _race.Horses.Count;
            UpdatePickedHorse();
        }
        private void HorseNext_Click(object s, RoutedEventArgs e)
        {
            if (_race.Horses.Count == 0) return;
            _betHorseIdx = (_betHorseIdx + 1) % _race.Horses.Count;
            UpdatePickedHorse();
        }
        private void Bet_Click(object s, RoutedEventArgs e)
        {
            if (!double.TryParse(TxtBet.Text, out double amt) || amt <= 0)
            { TxtBetStatus.Text = "Введіть коректну суму."; return; }

            if (_race.Horses.Count == 0) return;
            var horse = _race.Horses[_betHorseIdx];
            bool ok = _betting.PlaceBet(horse, amt);
            TxtBetStatus.Text = ok
                ? $"✅ {amt:F0}$ на {horse.Name} (x{horse.Coefficient:F2})"
                : "❌ Недостатньо коштів або ставка вже зроблена.";
        }

        protected override void OnRenderSizeChanged(SizeChangedInfo s)
        {
            base.OnRenderSizeChanged(s);
            Dispatcher.InvokeAsync(BuildRenderer);
        }

        // ══════════════════════════════════════════════════════════════════════
        //  VORONOI TAB
        // ══════════════════════════════════════════════════════════════════════

        private void InitVorColorPicker()
        {
            foreach (var c in VorPalette)
            {
                var r = new Rectangle
                {
                    Width = 22, Height = 22,
                    Fill = new SolidColorBrush(c),
                    Stroke = Brushes.Transparent,
                    StrokeThickness = 2,
                    Margin = new Thickness(2),
                    Cursor = Cursors.Hand
                };
                var captured = c;
                r.MouseLeftButtonDown += (_, _) =>
                {
                    _vorColor = captured;
                    foreach (var ch in ColorPicker.Children.OfType<Rectangle>())
                        ch.Stroke = Brushes.Transparent;
                    r.Stroke = Brushes.White;
                };
                ColorPicker.Children.Add(r);
            }
            if (ColorPicker.Children.Count > 0)
                ((Rectangle)ColorPicker.Children[0]).Stroke = Brushes.White;
        }

        private void Vor_MouseDown(object s, MouseButtonEventArgs e)
        {
            var pos = e.GetPosition(VorImg);
            _voronoi.AddPoint(pos.X, pos.Y, _vorColor);
            TxtVorHint.Visibility = Visibility.Hidden;
            RedrawDots();
        }

        private void Vor_RightClick(object s, MouseButtonEventArgs e)
        {
            _voronoi.RemoveLastPoint();
            if (_voronoi.Points.Count == 0) TxtVorHint.Visibility = Visibility.Visible;
            RedrawDots();
        }

        private void GenRnd_Click(object s, RoutedEventArgs e)
        {
            if (!int.TryParse(TxtRndCount.Text, out int n)) n = 12;
            n = Math.Clamp(n, 1, 300);
            _voronoi.AddRandomPoints(n,
                Math.Max(1, VorImg.ActualWidth),
                Math.Max(1, VorImg.ActualHeight),
                VorPalette);
            TxtVorHint.Visibility = Visibility.Hidden;
            RedrawDots();
        }

        private void RemLast_Click(object s, RoutedEventArgs e) { _voronoi.RemoveLastPoint(); RedrawDots(); }

        private void ClearVor_Click(object s, RoutedEventArgs e)
        {
            _voronoi.Clear();
            VorImg.Source = null;
            VorDots.Children.Clear();
            TxtVorHint.Visibility = Visibility.Visible;
            TxtVStats.Text = "";
            TxtLoci.Text   = "";
        }

        private void BuildVor_Click(object s, RoutedEventArgs e)
        {
            if (_voronoi.Points.Count == 0)
            { MessageBox.Show("Додайте точки!", "Увага", MessageBoxButton.OK, MessageBoxImage.Warning); return; }

            int w = Math.Max(10, (int)VorImg.ActualWidth);
            int h = Math.Max(10, (int)VorImg.ActualHeight);

            _voronoi.Metric = CmbMetric.SelectedIndex switch
            {
                1 => VoronoiMetric.Manhattan,
                2 => VoronoiMetric.Chebyshev,
                _ => VoronoiMetric.Euclidean
            };
            var mode = RbMulti.IsChecked == true ? VoronoiMode.MultiThread : VoronoiMode.SingleThread;

            var (bmp, realMs, cpuMs, memMB) = _voronoi.Generate(w, h, mode);
            VorImg.Source = bmp;

            string modeStr = mode == VoronoiMode.MultiThread
                ? $"Багатопотоковий ({Environment.ProcessorCount} потоки)"
                : "Однопотоковий";

            TxtVStats.Text =
                $"Точок: {_voronoi.Points.Count}\n" +
                $"Режим: {modeStr}\n" +
                $"Метрика: {_voronoi.Metric}\n" +
                $"Реальний час: {realMs} мс\n" +
                $"CPU час: {cpuMs:F1} мс\n" +
                $"Пам'ять: ~{memMB:F1} МБ";

            TxtLoci.Text = string.Join("\n",
                _voronoi.Points
                    .Select((p, i) => $"Точка {i + 1}: {p.PixelCount:N0} px")
                    .Take(15));
        }

        private void Metric_Changed(object s, SelectionChangedEventArgs e)
        {
            if (VorImg?.Source != null && _voronoi.Points.Count > 0)
                BuildVor_Click(s, e);
        }

        private void RedrawDots()
        {
            VorDots.Children.Clear();
            foreach (var (pt, idx) in _voronoi.Points.Select((p, i) => (p, i)))
            {
                var dot = new Ellipse
                {
                    Width = 12, Height = 12,
                    Fill   = new SolidColorBrush(Colors.White),
                    Stroke = new SolidColorBrush(pt.Color),
                    StrokeThickness = 2.5
                };
                Canvas.SetLeft(dot, pt.X - 6);
                Canvas.SetTop(dot,  pt.Y - 6);
                VorDots.Children.Add(dot);

                var lbl = new TextBlock
                {
                    Text       = (idx + 1).ToString(),
                    Foreground = Brushes.White,
                    FontSize   = 9, FontWeight = FontWeights.Bold
                };
                Canvas.SetLeft(lbl, pt.X + 8);
                Canvas.SetTop(lbl,  pt.Y - 8);
                VorDots.Children.Add(lbl);
            }
        }
    }
}