using System.Windows;

namespace HorseRaceApp
{
    public partial class App : Application { }
}
