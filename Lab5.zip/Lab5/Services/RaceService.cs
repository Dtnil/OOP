using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using HorseRaceApp.Models;

namespace HorseRaceApp.Services
{
    public class RaceService
    {
        public ObservableCollection<Horse> Horses { get; } = new();
        public bool   IsRunning   { get; private set; }
        public double TraceLength => 740.0;

        public event Action? RenderTick;
        public event Action? RaceFinished;

        private CancellationTokenSource _cts = new();
        private readonly Stopwatch _timer = new();
        private int _finishCount;

        private static readonly string[] Names =
            { "Lucky","Ranger","Willow","Tucker","Shadow","Blaze","Storm","Comet","Dash","Spirit" };

        // Exactly 6 colors — one per color folder (red/blue/green/yellow/purple/orange)
        public static readonly (System.Windows.Media.Color Color, string Folder)[] HorseColors =
        {
            (System.Windows.Media.Color.FromRgb(220,  50,  50), "red"),
            (System.Windows.Media.Color.FromRgb( 50, 100, 220), "blue"),
            (System.Windows.Media.Color.FromRgb( 50, 180,  80), "green"),
            (System.Windows.Media.Color.FromRgb(220, 190,  30), "yellow"),
            (System.Windows.Media.Color.FromRgb(160,  50, 200), "purple"),
            (System.Windows.Media.Color.FromRgb(230, 120,  30), "orange"),
        };

        public void SetHorseCount(int count)
        {
            Horses.Clear();
            count = Math.Clamp(count, 2, 10);
            for (int i = 0; i < count; i++)
            {
                var (color, _) = HorseColors[i % HorseColors.Length];
                Horses.Add(new Horse($"{i + 1}.{Names[i % Names.Length]}", color, i));
            }
        }

        public async Task StartRace()
        {
            if (IsRunning) return;
            IsRunning    = true;
            _finishCount = 0;
            _cts         = new CancellationTokenSource();

            foreach (var h in Horses) h.Reset();
            _timer.Restart();

            var horseTasks = Horses
                .Select(h => h.ChangeAcceleration(TraceLength, _timer, _cts.Token))
                .ToList();

            var renderTask = Task.Run(async () =>
            {
                while (IsRunning && !_cts.Token.IsCancellationRequested)
                {
                    Application.Current.Dispatcher.Invoke(Step);
                    await Task.Delay(16).ConfigureAwait(false);
                }
            });

            await Task.WhenAll(horseTasks).ConfigureAwait(false);

            IsRunning = false;
            _cts.Cancel();
            await renderTask.ContinueWith(_ => { }).ConfigureAwait(false);

            // Run final step and coefficients synchronously, then fire the event
            // via BeginInvoke so MessageBox inside the handler doesn't block this thread
            Application.Current.Dispatcher.Invoke(() =>
            {
                Step();
                _timer.Stop();
                PostRaceCoefficients();
            });

            Application.Current.Dispatcher.BeginInvoke(() => RaceFinished?.Invoke());
        }

        public void StopRace()
        {
            IsRunning = false;
            _cts.Cancel();
            _timer.Stop();
        }

        private void Step()
        {
            foreach (var h in Horses.Where(h => !h.Finished))
            {
                h.PositionX = Math.Min(h.PositionX + h.Acceleration, TraceLength);
                h.AdvanceFrame();

                if (h.PositionX >= TraceLength && !h.Finished)
                {
                    h.Finished = true;
                    h.RaceTime = _timer.Elapsed;
                    int rank   = Interlocked.Increment(ref _finishCount);
                    h.Position = rank;
                }
            }

            int nextRank = _finishCount + 1;
            var running  = Horses.Where(h => !h.Finished)
                                 .OrderByDescending(h => h.PositionX)
                                 .ToList();
            for (int i = 0; i < running.Count; i++)
                running[i].Position = nextRank + i;

            // Оновлюємо коефіцієнти на основі поточних позицій при кожному кроці.
            // Завдяки цьому до фінішу коефіцієнти вже відображають реальний порядок —
            // різкого стрибка після фінішу не відбувається.
            RecalculateCoefficients();

            RenderTick?.Invoke();
        }

        /// <summary>
        /// Розраховує коефіцієнти для всіх коней на основі їхньої поточної позиції.
        /// Переможець (місце 1) завжди отримує найменший коефіцієнт (1.10),
        /// останній — найбільший. Значення рівномірно розподіляються між 1.10 та 5.50
        /// залежно від кількості коней у забігу.
        /// </summary>
        private void RecalculateCoefficients()
        {
            int n = Horses.Count;
            if (n == 0) return;

            const double minCoeff = 1.10;
            const double maxCoeff = 5.50;

            foreach (var h in Horses)
            {
                // Position завжди в діапазоні [1..n]; нормалізуємо до [0..1]
                double t = n == 1 ? 0.0 : (double)(h.Position - 1) / (n - 1);
                h.Coefficient = Math.Round(minCoeff + t * (maxCoeff - minCoeff), 2);
            }
        }

        private void PostRaceCoefficients()
        {
            // Після фінішу викликаємо той самий метод — всі коні вже мають
            // фінальні місця, тому коефіцієнти просто підтверджуються без стрибка.
            RecalculateCoefficients();
        }

        public Horse? Winner =>
            Horses.Where(h => h.Finished && h.Position == 1).FirstOrDefault();
    }
}