using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace HorseRaceApp.Services
{
    public enum VoronoiMetric { Euclidean, Manhattan, Chebyshev }
    public enum VoronoiMode   { SingleThread, MultiThread }

    public class VoronoiPoint
    {
        public double X          { get; set; }
        public double Y          { get; set; }
        public Color  Color      { get; set; }
        public int PixelCount;
    }

    /// <summary>
    /// Computes a Voronoi diagram by brute-force pixel enumeration.
    /// Supports single-thread and multi-thread (one task per CPU partition) modes.
    /// </summary>
    public class VoronoiService
    {
        public List<VoronoiPoint> Points { get; } = new();
        public VoronoiMetric      Metric { get; set; } = VoronoiMetric.Euclidean;

        private static readonly Random _rng = new();

        // ── Point management ──────────────────────────────────────────────────
        public void AddPoint(double x, double y, Color color)
            => Points.Add(new VoronoiPoint { X = x, Y = y, Color = color });

        public void AddRandomPoints(int count, double width, double height, Color[] palette)
        {
            for (int i = 0; i < count; i++)
            {
                var color = palette[(Points.Count) % palette.Length];
                AddPoint(_rng.NextDouble() * width, _rng.NextDouble() * height, color);
            }
        }

        public void RemoveLastPoint()
        {
            if (Points.Count > 0) Points.RemoveAt(Points.Count - 1);
        }

        public void Clear() => Points.Clear();

        // ── Diagram generation ────────────────────────────────────────────────
        /// <returns>(bitmap, realTimeMs, cpuTimeMs, memoryMB)</returns>
        public (WriteableBitmap bmp, long realMs, double cpuMs, double memMB) Generate(
            int width, int height, VoronoiMode mode)
        {
            var bmp = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
            if (Points.Count == 0) return (bmp, 0, 0, 0);

            // Reset pixel counts
            foreach (var p in Points) p.PixelCount = 0;

            // Pixel buffer
            var pixels = new byte[width * height * 4];

            // Take snapshot of points for thread safety
            var pts = Points.ToArray();

            var sw       = Stopwatch.StartNew();
            var cpuStart = Process.GetCurrentProcess().TotalProcessorTime;
            long memBefore = GC.GetTotalMemory(false);

            if (mode == VoronoiMode.SingleThread)
            {
                ComputeRegion(0, height, width, pixels, pts);
            }
            else
            {
                // Partition into horizontal strips — one Task per logical CPU
                int threadCount = Environment.ProcessorCount;
                int rowsPerPart = height / threadCount;
                var tasks = new Task[threadCount];

                for (int t = 0; t < threadCount; t++)
                {
                    int startRow = t * rowsPerPart;
                    int endRow   = (t == threadCount - 1) ? height : startRow + rowsPerPart;
                    int captT    = t;
                    tasks[captT] = Task.Run(() =>
                        ComputeRegion(startRow, endRow, width, pixels, pts));
                }
                Task.WaitAll(tasks);
            }

            sw.Stop();
            double cpuMs  = (Process.GetCurrentProcess().TotalProcessorTime - cpuStart).TotalMilliseconds;
            double memMB  = (GC.GetTotalMemory(false) - memBefore + pixels.LongLength) / 1_048_576.0;

            // Write pixels to WriteableBitmap on UI thread
            bmp.WritePixels(new Int32Rect(0, 0, width, height), pixels, width * 4, 0);
            return (bmp, sw.ElapsedMilliseconds, cpuMs, memMB);
        }

        // ── Inner computation (thread-safe per-row region) ────────────────────
        private void ComputeRegion(int startRow, int endRow, int width,
                                   byte[] pixels, VoronoiPoint[] pts)
        {
            for (int y = startRow; y < endRow; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    double minDist = double.MaxValue;
                    int    nearest = 0;

                    for (int i = 0; i < pts.Length; i++)
                    {
                        double d = Distance(x, y, pts[i].X, pts[i].Y);
                        if (d < minDist) { minDist = d; nearest = i; }
                    }

                    // Thread-safe pixel count increment
                    System.Threading.Interlocked.Increment(ref pts[nearest].PixelCount);

                    var c   = pts[nearest].Color;
                    int idx = (y * width + x) * 4;
                    pixels[idx]     = c.B;
                    pixels[idx + 1] = c.G;
                    pixels[idx + 2] = c.R;
                    pixels[idx + 3] = 255;
                }
            }
        }

        private double Distance(double x1, double y1, double x2, double y2)
        {
            double dx = x1 - x2, dy = y1 - y2;
            return Metric switch
            {
                VoronoiMetric.Manhattan => Math.Abs(dx) + Math.Abs(dy),
                VoronoiMetric.Chebyshev => Math.Max(Math.Abs(dx), Math.Abs(dy)),
                _                       => Math.Sqrt(dx * dx + dy * dy)
            };
        }
    }
}
