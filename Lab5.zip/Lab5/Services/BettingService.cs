using System.ComponentModel;
using System.Runtime.CompilerServices;
using HorseRaceApp.Models;

namespace HorseRaceApp.Services
{
    public class BettingService : INotifyPropertyChanged
    {
        private double _balance   = 250.0;
        private double _betAmount = 25.0;
        private Horse? _bettedHorse;
        private bool   _hasBet;
        private double _lockedCoefficient;  // coefficient at the moment of bet placement

        public double Balance
        {
            get => _balance;
            set { _balance = value < 0 ? 0 : value; OnPropertyChanged(); }
        }

        public double BetAmount
        {
            get => _betAmount;
            set { _betAmount = value < 1 ? 1 : value; OnPropertyChanged(); }
        }

        public Horse? BettedHorse     { get => _bettedHorse; private set { _bettedHorse = value; OnPropertyChanged(); OnPropertyChanged(nameof(BettedHorseName)); } }
        public string BettedHorseName => _bettedHorse?.Name ?? "—";
        public bool   HasActiveBet    => _hasBet;

        public bool PlaceBet(Horse horse, double amount)
        {
            if (_hasBet || amount > Balance || amount <= 0) return false;
            BettedHorse        = horse;
            _lockedCoefficient = horse.Coefficient;  // save coefficient NOW, before race changes it
            Balance           -= amount;
            BetAmount          = amount;
            _hasBet            = true;
            return true;
        }

        public double SettleBet(Horse winner)
        {
            if (!_hasBet || BettedHorse == null) { _hasBet = false; return 0; }

            double won = 0;
            if (BettedHorse == winner)
            {
                // Use the locked coefficient from bet time, not the post-race recalculated one
                won                  = BetAmount * _lockedCoefficient;
                Balance             += won;
                BettedHorse.Winnings = won;
            }
            _hasBet     = false;
            BettedHorse = null;
            return won;
        }

        public void Reset() { _hasBet = false; BettedHorse = null; }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? n = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }
}
