using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using HorseRaceApp.Models;

namespace HorseRaceApp.Services
{
    /// <summary>
    /// Draws the race frame using pre-colored horse PNG sequences.
    /// Each horse color has its own folder: Assets/Horses/red/, blue/, green/, yellow/, purple/, orange/
    /// 12 animation frames per color (horse_0000.png – horse_0011.png).
    /// </summary>
    public class RenderService
    {
        private const double DpiX = 96, DpiY = 96;
        private const double PixelPerDip = 1.0;
        private const int FrameCount = 12;

        public double TraceLength   { get; }
        public double CameraOffsetX { get; set; } = 0;

        private readonly int _canvasW, _canvasH, _horseCount;

        // folder name → array of 12 frames
        private readonly Dictionary<string, BitmapSource[]> _frames = new();

        // color value → folder name (built from RaceService.HorseColors)
        private readonly Dictionary<Color, string> _colorToFolder = new();

        public RenderService(int canvasW, int canvasH, int horseCount, double traceLength)
        {
            _canvasW    = Math.Max(canvasW, 400);
            _canvasH    = Math.Max(canvasH, 100);
            _horseCount = Math.Max(horseCount, 1);
            TraceLength = traceLength;

            // Build color→folder map from the authoritative list in RaceService
            foreach (var (color, folder) in RaceService.HorseColors)
                _colorToFolder[color] = folder;

            LoadAllFrames();
        }

        private void LoadAllFrames()
        {
            string basePath = AppDomain.CurrentDomain.BaseDirectory;

            foreach (var (_, folder) in RaceService.HorseColors)
            {
                if (_frames.ContainsKey(folder)) continue;  // skip duplicates

                var frames = new BitmapSource[FrameCount];
                string dir = Path.Combine(basePath, "Assets", "Horses", folder);

                for (int i = 0; i < FrameCount; i++)
                {
                    string path = Path.Combine(dir, $"horse_{i:0000}.png");
                    if (File.Exists(path))
                    {
                        var bmp = new BitmapImage();
                        bmp.BeginInit();
                        bmp.UriSource   = new Uri(path);
                        bmp.CacheOption = BitmapCacheOption.OnLoad;
                        bmp.EndInit();
                        bmp.Freeze();
                        frames[i] = bmp;
                    }
                    else
                    {
                        frames[i] = MakeFallback(276, 180);
                    }
                }
                _frames[folder] = frames;
            }
        }

        private static BitmapSource MakeFallback(int w, int h)
        {
            // Grey placeholder so a missing file doesn't crash
            var px = new byte[w * h * 4];
            for (int i = 0; i < px.Length; i += 4)
            { px[i] = 80; px[i+1] = 80; px[i+2] = 80; px[i+3] = 180; }
            var src = BitmapSource.Create(w, h, DpiX, DpiY, PixelFormats.Bgra32, null, px, w*4);
            src.Freeze();
            return src;
        }

        private BitmapSource GetFrame(Color horseColor, int frameIdx)
        {
            if (_colorToFolder.TryGetValue(horseColor, out string? folder) &&
                _frames.TryGetValue(folder, out var arr))
                return arr[frameIdx % FrameCount];

            // Fallback: use first available folder
            var first = _frames.Values.FirstOrDefault();
            return first?[frameIdx % FrameCount] ?? MakeFallback(276, 180);
        }

        public BitmapSource RenderFrame(IList<Horse> horses)
        {
            int w = _canvasW, h = _canvasH;
            double laneH  = (double)h / _horseCount;
            double scaleX = w / TraceLength;

            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                // Sky
                var sky = new LinearGradientBrush(
                    Color.FromRgb(25, 55, 115),
                    Color.FromRgb(70, 130, 190),
                    new Point(0, 0), new Point(0, 1));
                dc.DrawRectangle(sky, null, new Rect(0, 0, w, h * 0.4));

                // Grass
                dc.DrawRectangle(new SolidColorBrush(Color.FromRgb(46, 125, 50)),
                    null, new Rect(0, h * 0.4, w, h * 0.6));

                // Lane strips
                for (int i = 0; i < _horseCount; i++)
                    if (i % 2 == 1)
                        dc.DrawRectangle(new SolidColorBrush(Color.FromArgb(30, 0, 0, 0)),
                            null, new Rect(0, i * laneH, w, laneH));

                // Lane lines
                var lanePen = new Pen(new SolidColorBrush(Color.FromArgb(70, 255, 255, 255)), 1);
                for (int i = 1; i < _horseCount; i++)
                    dc.DrawLine(lanePen, new Point(0, i * laneH), new Point(w, i * laneH));

                // Start line
                double startX = 0 - CameraOffsetX;
                if (startX >= 0 && startX <= w)
                    dc.DrawRectangle(new SolidColorBrush(Color.FromArgb(160, 255, 255, 255)),
                        null, new Rect(startX, 0, 3, h));

                // Finish line (checkered)
                double finishX = TraceLength * scaleX - CameraOffsetX;
                if (finishX >= -10 && finishX <= w + 10)
                {
                    int sq = 12;
                    for (int yi = 0; yi < h; yi += sq)
                    {
                        bool dark = (yi / sq) % 2 == 0;
                        dc.DrawRectangle(dark ? Brushes.Black : Brushes.Yellow,
                            null, new Rect(finishX - 4, yi, 8, sq));
                    }
                    var ft = new FormattedText("ФІНІШ",
                        System.Globalization.CultureInfo.InvariantCulture,
                        FlowDirection.LeftToRight,
                        new Typeface(new FontFamily("Arial"), FontStyles.Normal,
                            FontWeights.Bold, FontStretches.Normal),
                        11, Brushes.Yellow, PixelPerDip);
                    dc.DrawText(ft, new Point(finishX + 8, 4));
                }

                // Horses
                var sampleArr = _frames.Values.FirstOrDefault();
                int fw = sampleArr?[0].PixelWidth  ?? 276;
                int fh = sampleArr?[0].PixelHeight ?? 180;

                for (int i = 0; i < horses.Count; i++)
                {
                    var horse = horses[i];
                    double sx = horse.PositionX * scaleX - CameraOffsetX;

                    double targetH = laneH * 0.85;
                    double scale   = targetH / fh;
                    double dw      = fw * scale;
                    double dy      = horse.LaneIndex * laneH + (laneH - targetH) / 2.0;

                    var frame = GetFrame(horse.Color, horse.FrameIndex);
                    dc.DrawImage(frame, new Rect(sx - dw / 2, dy, dw, targetH));

                    if (sx > -dw && sx < w + dw)
                    {
                        var tf = new FormattedText(horse.Name,
                            System.Globalization.CultureInfo.InvariantCulture,
                            FlowDirection.LeftToRight,
                            new Typeface("Arial"), 9.5,
                            new SolidColorBrush(horse.Color),
                            PixelPerDip);
                        dc.DrawText(tf, new Point(sx - dw / 2, dy - 14));
                    }
                }
            }

            var rtb = new RenderTargetBitmap(w, h, DpiX, DpiY, PixelFormats.Pbgra32);
            rtb.Render(dv);
            rtb.Freeze();
            return rtb;
        }
    }
}
